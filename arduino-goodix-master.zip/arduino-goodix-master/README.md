# arduino-goodix
Arduino goodix touch screen driver

Prototype of arduino-based library for Goodix touchscreen driver chips (tested with GT911 GT9110)
Thanks to linux/android Goodix drivers developers for references
* https://github.com/goodix/gt1x_driver_generic
* https://github.com/hadess/gt9xx (Also You can found specs in this repo)

![Hardware](https://github.com/ploys/arduino-goodix/blob/master/img/lenovoTC.jpg)
